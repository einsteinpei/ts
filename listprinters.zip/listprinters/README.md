# List printers
Retrieve connected printers